﻿Important: this plugin does not works at the moment. See https://dotspatial.codeplex.com/workitem/25612

LiDAR support.